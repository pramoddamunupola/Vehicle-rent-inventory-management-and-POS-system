import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class Datainsert {

    public void Datainsert(char operation, String licensPlate, String category, String vehicleColour, float fuelConsumption, String availability, float rentpday, float rentpekm, float rentpeday, String ownerid, String ownername, String owneraddress, Integer ownercontactno, String model, String imagePath) {
        
        Connection con = MYConnection.getConnection();
        PreparedStatement ps = null;
        
        // i for insert
        if (operation == 'i') {
            try {
                ps = con.prepareStatement("INSERT INTO vehicle(licens_plate, vehicle_category, vehicle_colour, vehicle_fuel_consumption_P1l, vehicle_rent_pday, vehicle_availability, vehicle_rent_pekm, vehicle_rent_peday, vehicle_owner_id, vehicle_owner_name, vehicle_owner_address, vehicle_owner_contactno, vehicle_model, vehicle_image) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                ps.setString(1, licensPlate);
                ps.setString(2, category);
                ps.setString(3, vehicleColour);
                ps.setFloat(4, fuelConsumption);
                ps.setFloat(5, rentpday);
                ps.setString(6, availability);
                ps.setFloat(7, rentpekm);
                ps.setFloat(8, rentpeday);
                ps.setString(9, ownerid);
                ps.setString(10, ownername);
                ps.setString(11, owneraddress);
                ps.setInt(12, ownercontactno);
                ps.setString(13, model);
                ps.setString(14, imagePath);
                
                if (ps.executeUpdate() > 0) {
                    JOptionPane.showMessageDialog(null, "New vehicle added");
                }
            } catch (SQLException ex) {
                Logger.getLogger(Datainsert.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                // Close resources
                if (ps != null) {
                    try {
                        ps.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(Datainsert.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                if (con != null) {
                    try {
                        con.close();
                    } catch (SQLException ex) {
                        Logger.getLogger(Datainsert.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
    }
}
