
import com.mysql.cj.xdevapi.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MYConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/vehiclerent";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static Connection getConnection() {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Connection successful!");
        } catch (ClassNotFoundException e) {
            System.err.println("Driver not found. Ensure the MySQL Connector/J JAR is added to your project.");
        } catch (SQLException e) {
            System.err.println("Failed to connect to the database. Check the URL, username, and password.");
        }
        return connection;
    }

    Statement creatStatement() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    
}
