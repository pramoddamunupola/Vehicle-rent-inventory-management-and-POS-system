
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Rentbill extends javax.swing.JFrame {
   public static Date fdate;
   public static float advanced;
   public static float total_cost;
   public static String customer_name;
   public static String customer_id;
   public static String rentID;
   public static String vehicle_model;
   public static String vehicle_licence_plate;
   public static float fbalance;
   
    public Rentbill() {
        initComponents();
    }
    

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jRadioButton1 = new javax.swing.JRadioButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        date_chooser = new de.wannawork.jcalendar.JCalendarComboBox();

        jRadioButton1.setText("jRadioButton1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jButton1.setText("Pay");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Cancel");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jLabel3.setText("Current Milage :");

        jLabel4.setText("Vehicle returned date :");

        jLabel5.setText("km");

        date_chooser.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                date_chooserPropertyChange(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jButton2)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5))
                    .addComponent(date_chooser, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(203, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel5))
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jButton2)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(date_chooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        try {
            String numberPlate = Home.licence_plate;
            String rent_id = Home.rentID;
            Connection con = MYConnection.getConnection();
            Statement st = con.createStatement();
            String query1 ="SELECT * FROM vehicle WHERE licens_plate ="+ numberPlate;
            String query2 ="SELECT * FROM rent WHERE rent_id ="+ rent_id;
            Statement st2 = con.createStatement();

            ResultSet rs1 = st.executeQuery(query1);
            ResultSet rs2 = st2.executeQuery(query2);
            rs1.next();
            rs2.next();
            
 //geting vehicle details from database
 float rentPday = rs1.getFloat("vehicle_rent_pday");
 float extra_km_price = rs1.getFloat("vehicle_rent_pekm");
 float price_per_day = rs1.getFloat("vehicle_rent_pday");
 vehicle_model = rs1.getString("vehicle_model");
 vehicle_licence_plate = rs1.getString("licens_plate");
//passing values
float mile_before = rs2.getFloat("mileage_b_rent");
float mile_after =(int)Double.parseDouble(jTextField1.getText());;
customer_name = rs2.getString("person_name");
customer_id = rs2.getString("person_id");
rentID = rent_id;
advanced = rs2.getFloat("advanced_amount");
float maxkm = rs1.getFloat("vehicle_rent_peday");
float balance;

//end of passing values
Date rent_date = rs2.getDate("rent_date");
 
Date pay_date = date_chooser.getDate();
fdate = pay_date;

System.out.println(pay_date);
System.out.println(rent_date);

//calculating days


            // Calucalte time difference in milliseconds   
            long time_difference = pay_date.getTime() - rent_date.getTime();  
            // Calucalte time difference in days  
            long days_difference = (time_difference / (1000*60*60*24)) % 365; 
            
           System.out.println(days_difference); 



// Initializing the variables

float total_miles;
int days =  (int) days_difference;

float total;


// Calculate total miles
total_miles = mile_after - mile_before;

// Calculate total cost
        if (total_miles > maxkm) {
            total = (price_per_day*days) + (total_miles - maxkm) * extra_km_price;
        } else {
            total = price_per_day*days;
            
        }
        balance = total-advanced;
        //passing values
        total_cost=total;
        fbalance = balance;
        //End passing values
        //updating table details////////
        PreparedStatement ps;
        ps = con.prepareStatement("UPDATE vehicle SET vehicle_availability = 'yes' WHERE licens_plate ="+ numberPlate) ;
        PreparedStatement ps2;
        ps2 =con.prepareStatement("UPDATE rent SET rent_status = 'Completed' WHERE rent_id ="+ rent_id);
        
        ps.execute();
        ps2.execute();
        // END UPDATING TABLES///////////////////////////////
        
        //set bill
        Billprint bill = new Billprint();
        bill.setbill();
        bill.setVisible(rootPaneCheckingEnabled);
        
// Output the total cost
System.out.println("Total cost: $" + total);

        } catch (SQLException ex) {
            Logger.getLogger(Rentbill.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
      this.dispose();  // TODO add your handling code here:
    }//GEN-LAST:event_jButton2ActionPerformed

    private void date_chooserPropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_date_chooserPropertyChange
        Date date = date_chooser.getDate(); 
        
    }//GEN-LAST:event_date_chooserPropertyChange

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Rentbill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Rentbill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Rentbill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Rentbill.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Rentbill().setVisible(true);
            }
        });
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private de.wannawork.jcalendar.JCalendarComboBox date_chooser;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JRadioButton jRadioButton1;
    private javax.swing.JTextField jTextField1;
    // End of variables declaration//GEN-END:variables
}
