import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Rentdatainsert {
    public static String rentalid;
    public void Datainsert(char operation, String name, String id, String contactno, String address, float bmilage, float a_amount, String image, String licens_plate, Date date, String status) {

        Connection con = MYConnection.getConnection();
        PreparedStatement ps = null;

        // 'i' for insert
        if (operation == 'i') {
            try {
                String sql = "INSERT INTO rent(person_id, person_name, person_contactno, person_adress, mileage_b_rent, advanced_amount, image_data, licens_plate, rent_date, rent_status) VALUES (?,?,?,?,?,?,?,?,?,?)";
                ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);

                ps.setString(1, id);
                ps.setString(2, name);
                ps.setString(3, contactno);
                ps.setString(4, address);
                ps.setFloat(5, bmilage);
                ps.setFloat(6, a_amount);
                ps.setString(7, image);
                ps.setString(8, licens_plate);
                ps.setString(10, status);

                // Convert java.util.Date to java.sql.Date
                java.sql.Date sqlDate = new java.sql.Date(date.getTime());
                ps.setDate(9, sqlDate);

                int affectedRows = ps.executeUpdate();

                if (affectedRows > 0) {
                    ResultSet generatedKeys = ps.getGeneratedKeys();
                    if (generatedKeys.next()) {
                        String newId = generatedKeys.getString(1);
                        System.out.println("New rent added with ID: " + newId);
                        rentalid = newId;
                    } else {
                        System.out.println("New rent added, but no ID obtained.");
                    }
                }
            } catch (SQLException ex) {
                Logger.getLogger(Rentdatainsert.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    if (ps != null) ps.close();
                    if (con != null) con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(Rentdatainsert.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
}
